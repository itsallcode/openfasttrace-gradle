// [impl->dsn~exampleA~1]
